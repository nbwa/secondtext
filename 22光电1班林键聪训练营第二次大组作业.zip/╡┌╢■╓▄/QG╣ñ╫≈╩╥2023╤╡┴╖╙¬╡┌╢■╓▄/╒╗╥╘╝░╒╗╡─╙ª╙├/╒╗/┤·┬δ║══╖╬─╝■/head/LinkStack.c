#include "LinkStack.h" 
#include"stdlib.h"
#include"stdio.h"

//��ջ

//��ʼ��ջ
Status initLStack(LinkStack* s)
{
	s->top = NULL;
	s->count = 0;
}

//�ж�ջ�Ƿ�Ϊ��
Status isEmptyLStack(LinkStack *s){
	if (s->count == 0)
		return ERROR;
	else
		return SUCCESS;

}

//�õ�ջ��Ԫ��
Status getTopLStack(LinkStack *s,ElemType *e){
	if (s->count)
	{
		*e = s->top->data;
		return SUCCESS;
	}

	else
	return ERROR;
}

//���ջ
Status clearLStack(LinkStack *s){
	LinkStackPtr p;
	while (s->count)
	{
		p = s->top;
		s->top = s->top->next;
		free(p);
		s->count--;
	}
	return SUCCESS;
}

//����ջ
Status destroyLStack(LinkStack *s){
	LinkStackPtr p;
	while (s->count)
	{
		p = s->top;
		s->top = s->top->next;
		free(p);
		s->count--;
	}
	p = s->top;
	free(p);

	return SUCCESS;
}

//���ջ����
Status LStackLength(LinkStack *s,int *length){
	*length = s->count;
}

//��ջ
Status pushLStack(LinkStack *s,ElemType data){
	LinkStackPtr q = (LinkStackPtr)malloc(sizeof(StackNode));
	q->data = data;
	q->next = s->top;
	s->top = q;
	s->count++;
	printf("��ջ�ɹ�\n");
}

//��ջ
Status popLStack(LinkStack *s,ElemType *data){
	LinkStackPtr p;
	if (s->count)
	{
		p = s->top;
		*data = s->top->data;
		s->top = s->top->next;
		free(p);
		s->count--;
		printf("��ջ�ɹ�\n");
		return SUCCESS;
	}
	else
	{
		printf("ջ�գ���ջʧ��");
		return ERROR;
	}
}

void clearpause()
{
	while (getchar() != '\n');
	while (getchar() != '\n');
}


